
Installing:

  The program will automatic install first time it is run, this can be disabled by putting "noinstall" on the command line.
  For other command line options see the webpage. 



A few notes about the program:

  Right click to get a menu (Works on most pages).
  
  If no other unit is specified then input fields are for basic SI values (meter, ohms, volts, etc.)

  It is possible to use SI-prefix after numbers, i.e. "10k" is a legal value
  Be carefull with "10m" and "10M" the first is 0.01, the second is 10000000

  All input fields can do calculations.

  RED fields means error in input, this may prevent update of page.

  Pages can be dragged outside main program, making it possible to view more pages simultaneous.

  Use Ctrl-N and Ctrl-M to step values.

  Remember to use "System, Prefered components" to set standard values (and step sizes).


If your find a bug or got a good idea for improvement, please send a mail to miscel@miscel.dk
        
  


